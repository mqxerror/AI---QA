const { chromium, firefox, webkit } = require('playwright');
const path = require('path');
const fs = require('fs').promises;
const { v4: uuidv4 } = require('uuid');
const logger = require('../utils/logger');
const storage = require('../utils/storage');

class PlaywrightService {
  constructor() {
    this.browsers = { chromium, firefox, webkit };
  }

  /**
   * Run smoke tests
   * @param {Object} config - Test configuration
   * @returns {Promise<Object>} - Test results
   */
  async runSmokeTests(config) {
    const {
      target_url,
      browser = 'chromium',
      viewport = { width: 1920, height: 1080 },
      tests = ['homepage_loads', 'navigation_works', 'no_console_errors', 'images_load']
    } = config;

    logger.info(`Running smoke tests on ${target_url}`, { browser, viewport });

    const browserInstance = await this.browsers[browser].launch({
      headless: true,
      args: ['--no-sandbox', '--disable-setuid-sandbox']
    });

    const context = await browserInstance.newContext({
      viewport,
      userAgent: 'Mozilla/5.0 (compatible; TestingAgent/1.0; +https://testing-agent.com)'
    });

    const page = await context.newPage();
    const results = [];
    const runId = uuidv4();

    try {
      // Collect console errors
      const consoleErrors = [];
      page.on('console', msg => {
        if (msg.type() === 'error') {
          consoleErrors.push(msg.text());
        }
      });

      // Test 1: Homepage loads
      if (tests.includes('homepage_loads')) {
        const startTime = Date.now();
        try {
          const response = await page.goto(target_url, { waitUntil: 'networkidle', timeout: 30000 });
          const duration = Date.now() - startTime;
          const status = response.status();

          const screenshotPath = `/app/artifacts/screenshots/${runId}-homepage.png`;
          await page.screenshot({ path: screenshotPath, fullPage: false });
          const screenshotUrl = await storage.uploadFile(screenshotPath, `screenshots/${runId}-homepage.png`, 'image/png');

          results.push({
            name: 'homepage_loads',
            status: status < 400 ? 'pass' : 'fail',
            duration_ms: duration,
            message: `HTTP ${status}`,
            screenshot: screenshotUrl
          });
        } catch (error) {
          results.push({
            name: 'homepage_loads',
            status: 'fail',
            duration_ms: Date.now() - startTime,
            error: error.message
          });
        }
      }

      // Test 2: No console errors
      if (tests.includes('no_console_errors')) {
        results.push({
          name: 'no_console_errors',
          status: consoleErrors.length === 0 ? 'pass' : 'fail',
          message: consoleErrors.length === 0 ? 'No console errors' : `${consoleErrors.length} console errors`,
          errors: consoleErrors.slice(0, 10) // Limit to first 10 errors
        });
      }

      // Test 3: All images load
      if (tests.includes('images_load')) {
        const startTime = Date.now();
        try {
          await page.waitForLoadState('networkidle');
          const images = await page.locator('img').all();
          let brokenImages = 0;

          for (const img of images) {
            const src = await img.getAttribute('src');
            if (src && !src.startsWith('data:')) {
              const naturalWidth = await img.evaluate((el) => el.naturalWidth);
              if (naturalWidth === 0) {
                brokenImages++;
              }
            }
          }

          results.push({
            name: 'images_load',
            status: brokenImages === 0 ? 'pass' : 'fail',
            duration_ms: Date.now() - startTime,
            message: brokenImages === 0 ? `All ${images.length} images loaded` : `${brokenImages}/${images.length} images failed`,
            total_images: images.length,
            broken_images: brokenImages
          });
        } catch (error) {
          results.push({
            name: 'images_load',
            status: 'fail',
            error: error.message
          });
        }
      }

      // Test 4: Navigation works
      if (tests.includes('navigation_works')) {
        const startTime = Date.now();
        try {
          const navLinks = await page.locator('nav a, header a').filter({ hasText: /.+/ }).all();
          const linkCount = navLinks.length;

          results.push({
            name: 'navigation_works',
            status: linkCount > 0 ? 'pass' : 'fail',
            duration_ms: Date.now() - startTime,
            message: `Found ${linkCount} navigation links`,
            link_count: linkCount
          });
        } catch (error) {
          results.push({
            name: 'navigation_works',
            status: 'fail',
            error: error.message
          });
        }
      }

      // Test 5: Links valid (first 20)
      if (tests.includes('links_valid')) {
        const startTime = Date.now();
        try {
          const links = await page.locator('a[href]').all();
          const brokenLinks = [];

          for (const link of links.slice(0, 20)) {
            const href = await link.getAttribute('href');
            if (href && href.startsWith('http')) {
              try {
                const response = await page.request.head(href);
                if (response.status() >= 400) {
                  brokenLinks.push({ url: href, status: response.status() });
                }
              } catch (e) {
                brokenLinks.push({ url: href, error: 'failed' });
              }
            }
          }

          results.push({
            name: 'links_valid',
            status: brokenLinks.length === 0 ? 'pass' : 'fail',
            duration_ms: Date.now() - startTime,
            message: brokenLinks.length === 0 ? 'All links valid' : `${brokenLinks.length} broken links`,
            broken_links: brokenLinks
          });
        } catch (error) {
          results.push({
            name: 'links_valid',
            status: 'fail',
            error: error.message
          });
        }
      }

    } catch (error) {
      logger.error('Smoke test error:', error);
      throw error;
    } finally {
      await context.close();
      await browserInstance.close();
    }

    const totalDuration = results.reduce((sum, r) => sum + (r.duration_ms || 0), 0);
    const passed = results.filter(r => r.status === 'pass').length;
    const failed = results.filter(r => r.status === 'fail').length;

    return {
      success: failed === 0,
      duration_ms: totalDuration,
      results,
      summary: {
        total: results.length,
        passed,
        failed
      },
      browser,
      viewport: `${viewport.width}x${viewport.height}`
    };
  }

  /**
   * Run pixel audit tests
   * @param {Object} config - Test configuration
   * @returns {Promise<Object>} - Audit results
   */
  async runPixelAudit(config) {
    const {
      target_url,
      incognito = true,
      expected_pixels = [],
      capture_har = true
    } = config;

    logger.info(`Running pixel audit on ${target_url}`);

    const browser = await chromium.launch({
      headless: true,
      args: ['--no-sandbox', '--disable-setuid-sandbox']
    });

    const context = await browser.newContext({
      viewport: { width: 1920, height: 1080 }
    });

    const page = await context.newPage();
    const networkRequests = [];
    const runId = uuidv4();

    // Capture network requests
    page.on('request', request => {
      networkRequests.push({
        url: request.url(),
        method: request.method(),
        resourceType: request.resourceType()
      });
    });

    try {
      await page.goto(target_url, { waitUntil: 'networkidle' });
      await page.waitForTimeout(3000); // Wait for delayed scripts

      const pixelsFound = [];

      // Check for GA4
      const ga4Requests = networkRequests.filter(r =>
        r.url.includes('google-analytics.com') ||
        r.url.includes('googletagmanager.com/gtag') ||
        r.url.includes('analytics.google.com')
      );

      if (ga4Requests.length > 0 || expected_pixels.includes('GA4')) {
        pixelsFound.push({
          name: 'GA4',
          detected: ga4Requests.length > 0,
          script_url: ga4Requests[0]?.url || null,
          network_calls: ga4Requests.length
        });
      }

      // Check for GTM
      const gtmRequests = networkRequests.filter(r =>
        r.url.includes('googletagmanager.com/gtm.js')
      );
      const gtmScript = await page.locator('script[src*="googletagmanager.com/gtm"]').count();

      if (gtmRequests.length > 0 || gtmScript > 0 || expected_pixels.includes('GTM')) {
        const gtmContainer = await page.evaluate(() => {
          const match = document.documentElement.innerHTML.match(/GTM-[A-Z0-9]+/);
          return match ? match[0] : null;
        });

        pixelsFound.push({
          name: 'GTM',
          detected: gtmRequests.length > 0 || gtmScript > 0,
          container_id: gtmContainer,
          script_url: gtmRequests[0]?.url || null
        });
      }

      // Check for Meta Pixel
      const metaRequests = networkRequests.filter(r =>
        r.url.includes('facebook.com/tr') ||
        r.url.includes('connect.facebook.net')
      );
      const hasFbq = await page.evaluate(() => typeof window.fbq !== 'undefined');

      if (metaRequests.length > 0 || hasFbq || expected_pixels.includes('Meta Pixel')) {
        const pixelId = await page.evaluate(() => {
          const match = document.documentElement.innerHTML.match(/fbq\('init',\s*'(\d+)'/);
          return match ? match[1] : null;
        });

        pixelsFound.push({
          name: 'Meta Pixel',
          detected: metaRequests.length > 0 || hasFbq,
          pixel_id: pixelId,
          script_url: metaRequests[0]?.url || null,
          events: metaRequests.filter(r => r.url.includes('/tr')).length
        });
      }

      // Take screenshot
      const screenshotPath = `/app/artifacts/screenshots/${runId}-pixel-audit.png`;
      await page.screenshot({ path: screenshotPath, fullPage: true });
      const screenshotUrl = await storage.uploadFile(screenshotPath, `screenshots/${runId}-pixel-audit.png`, 'image/png');

      // Save HAR if requested
      let harUrl = null;
      if (capture_har) {
        const harPath = `/app/artifacts/har/${runId}-audit.json`;
        await fs.writeFile(harPath, JSON.stringify({ log: { entries: networkRequests } }, null, 2));
        harUrl = await storage.uploadFile(harPath, `har/${runId}-audit.json`, 'application/json');
      }

      // Determine missing pixels
      const detectedNames = pixelsFound.filter(p => p.detected).map(p => p.name);
      const missingPixels = expected_pixels.filter(p => !detectedNames.includes(p));

      return {
        success: true,
        pixels_found: pixelsFound,
        missing_pixels: missingPixels,
        total_network_requests: networkRequests.length,
        screenshot_url: screenshotUrl,
        har_url: harUrl
      };

    } catch (error) {
      logger.error('Pixel audit error:', error);
      throw error;
    } finally {
      await context.close();
      await browser.close();
    }
  }
}

module.exports = new PlaywrightService();
