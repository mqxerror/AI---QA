"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const playwright_1 = require("playwright");
const pngjs_1 = require("pngjs");
const fs_1 = __importDefault(require("fs"));
const path_1 = __importDefault(require("path"));
class VisualRegression {
    static screenshotsDir = path_1.default.join(process.cwd(), 'screenshots');
    static baselineDir = path_1.default.join(process.cwd(), 'screenshots', 'baseline');
    static diffDir = path_1.default.join(process.cwd(), 'screenshots', 'diff');
    // Standard viewports to test
    static viewports = [
        { name: 'desktop', width: 1920, height: 1080 },
        { name: 'tablet', width: 768, height: 1024 },
        { name: 'mobile', width: 375, height: 667 }
    ];
    /**
     * Run visual regression test on a URL
     */
    static async runTest(url, websiteId, createBaseline = false) {
        const startTime = Date.now();
        const issues = [];
        const comparisons = [];
        // Ensure directories exist
        this.ensureDirectories();
        let browser = null;
        try {
            browser = await playwright_1.chromium.launch({ headless: true });
            for (const viewport of this.viewports) {
                const context = await browser.newContext({
                    viewport: { width: viewport.width, height: viewport.height },
                    deviceScaleFactor: 1
                });
                const page = await context.newPage();
                // Navigate to page
                await page.goto(url, { waitUntil: 'networkidle', timeout: 30000 });
                // Wait a bit for any animations to settle
                await page.waitForTimeout(1000);
                // Generate file paths
                const sanitizedUrl = this.sanitizeFilename(url);
                const timestamp = Date.now();
                const screenshotFilename = `${websiteId}-${sanitizedUrl}-${viewport.name}-${timestamp}.png`;
                const baselineFilename = `${websiteId}-${sanitizedUrl}-${viewport.name}-baseline.png`;
                const diffFilename = `${websiteId}-${sanitizedUrl}-${viewport.name}-diff-${timestamp}.png`;
                const screenshotPath = path_1.default.join(this.screenshotsDir, screenshotFilename);
                const baselinePath = path_1.default.join(this.baselineDir, baselineFilename);
                const diffPath = path_1.default.join(this.diffDir, diffFilename);
                // Take screenshot
                await page.screenshot({
                    path: screenshotPath,
                    fullPage: true
                });
                await context.close();
                // Check if baseline exists
                const baselineExists = fs_1.default.existsSync(baselinePath);
                let comparison;
                if (createBaseline || !baselineExists) {
                    // Create baseline
                    if (fs_1.default.existsSync(screenshotPath)) {
                        fs_1.default.copyFileSync(screenshotPath, baselinePath);
                    }
                    comparison = {
                        viewport: viewport.name,
                        width: viewport.width,
                        height: viewport.height,
                        baseline_exists: false,
                        screenshot_path: screenshotFilename,
                        baseline_path: baselineFilename,
                        difference_percentage: 0,
                        pixels_changed: 0,
                        total_pixels: 0,
                        is_baseline_run: true,
                        passed: true
                    };
                }
                else {
                    // Compare with baseline
                    const comparisonResult = await this.compareScreenshots(baselinePath, screenshotPath, diffPath);
                    const passed = comparisonResult.difference_percentage < 1.0; // Less than 1% difference
                    comparison = {
                        viewport: viewport.name,
                        width: viewport.width,
                        height: viewport.height,
                        baseline_exists: true,
                        screenshot_path: screenshotFilename,
                        baseline_path: baselineFilename,
                        diff_path: diffFilename,
                        difference_percentage: comparisonResult.difference_percentage,
                        pixels_changed: comparisonResult.pixels_changed,
                        total_pixels: comparisonResult.total_pixels,
                        is_baseline_run: false,
                        passed
                    };
                    // Add issues if differences found
                    if (!passed) {
                        const severity = comparisonResult.difference_percentage > 5 ? 'critical' :
                            comparisonResult.difference_percentage > 2 ? 'warning' : 'info';
                        issues.push({
                            severity,
                            viewport: viewport.name,
                            difference_percentage: comparisonResult.difference_percentage,
                            pixels_changed: comparisonResult.pixels_changed,
                            description: `${comparisonResult.difference_percentage.toFixed(2)}% visual difference detected in ${viewport.name} viewport`
                        });
                    }
                }
                comparisons.push(comparison);
            }
            await browser.close();
            // Calculate summary
            const summary = {
                total_viewports: comparisons.length,
                passed: comparisons.filter(c => c.passed).length,
                failed: comparisons.filter(c => !c.passed).length,
                baseline_created: comparisons.filter(c => c.is_baseline_run).length
            };
            const isBaselineRun = summary.baseline_created > 0;
            const overall_score = this.calculateVisualScore(comparisons);
            return {
                success: summary.failed === 0,
                url,
                duration_ms: Date.now() - startTime,
                timestamp: new Date().toISOString(),
                overall_score,
                is_baseline_run: isBaselineRun,
                comparisons,
                issues,
                summary
            };
        }
        catch (error) {
            if (browser)
                await browser.close();
            throw new Error(`Visual regression test failed: ${error.message}`);
        }
    }
    /**
     * Compare two screenshots and return difference metrics
     */
    static async compareScreenshots(baselinePath, currentPath, diffPath) {
        try {
            // Dynamic import for ES module
            const pixelmatch = (await Promise.resolve().then(() => __importStar(require('pixelmatch')))).default;
            const baseline = pngjs_1.PNG.sync.read(fs_1.default.readFileSync(baselinePath));
            const current = pngjs_1.PNG.sync.read(fs_1.default.readFileSync(currentPath));
            const { width, height } = baseline;
            const diff = new pngjs_1.PNG({ width, height });
            // Ensure images are same size
            if (baseline.width !== current.width || baseline.height !== current.height) {
                throw new Error('Image dimensions do not match');
            }
            const pixelsDifferent = pixelmatch(baseline.data, current.data, diff.data, width, height, { threshold: 0.1 });
            const totalPixels = width * height;
            const differencePercentage = (pixelsDifferent / totalPixels) * 100;
            // Save diff image
            fs_1.default.writeFileSync(diffPath, pngjs_1.PNG.sync.write(diff));
            return {
                difference_percentage: differencePercentage,
                pixels_changed: pixelsDifferent,
                total_pixels: totalPixels
            };
        }
        catch (error) {
            throw new Error(`Screenshot comparison failed: ${error.message}`);
        }
    }
    /**
     * Calculate overall visual regression score (0-100)
     * 100 = no changes, 0 = massive changes
     */
    static calculateVisualScore(comparisons) {
        if (comparisons.length === 0)
            return 100;
        // If all are baseline runs, return 100
        if (comparisons.every(c => c.is_baseline_run))
            return 100;
        // Calculate average difference percentage
        const nonBaselineComparisons = comparisons.filter(c => !c.is_baseline_run);
        if (nonBaselineComparisons.length === 0)
            return 100;
        const avgDifference = nonBaselineComparisons.reduce((sum, c) => sum + c.difference_percentage, 0) / nonBaselineComparisons.length;
        // Convert to score (higher difference = lower score)
        // 0% diff = 100 score
        // 10% diff = 0 score
        const score = Math.max(0, 100 - (avgDifference * 10));
        return Math.round(score);
    }
    /**
     * Sanitize URL for filename
     */
    static sanitizeFilename(url) {
        return url
            .replace(/^https?:\/\//, '')
            .replace(/[^a-z0-9]/gi, '-')
            .toLowerCase()
            .substring(0, 50);
    }
    /**
     * Ensure required directories exist
     */
    static ensureDirectories() {
        [this.screenshotsDir, this.baselineDir, this.diffDir].forEach(dir => {
            if (!fs_1.default.existsSync(dir)) {
                fs_1.default.mkdirSync(dir, { recursive: true });
            }
        });
    }
    /**
     * Delete baseline for a website (to recreate)
     */
    static async deleteBaseline(websiteId, url) {
        try {
            const sanitizedUrl = this.sanitizeFilename(url);
            for (const viewport of this.viewports) {
                const baselineFilename = `${websiteId}-${sanitizedUrl}-${viewport.name}-baseline.png`;
                const baselinePath = path_1.default.join(this.baselineDir, baselineFilename);
                if (fs_1.default.existsSync(baselinePath)) {
                    fs_1.default.unlinkSync(baselinePath);
                }
            }
            return true;
        }
        catch (error) {
            console.error('Failed to delete baseline:', error);
            return false;
        }
    }
}
exports.default = VisualRegression;
//# sourceMappingURL=VisualRegression.js.map