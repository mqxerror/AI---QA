import { useState, useEffect } from 'react';
import api from '../services/api';
import { useActivityUpdates } from '../hooks/useRealtimeUpdates';
import './ActivityLog.css';

export default function ActivityLog() {
  const [activities, setActivities] = useState([]);
  const [stats, setStats] = useState(null);
  const [loading, setLoading] = useState(true);
  const [filters, setFilters] = useState({
    action: '',
    resource: '',
    status: '',
    limit: 100
  });

  // Real-time updates via WebSocket
  useActivityUpdates((data) => {
    // Prepend new activity to the list
    setActivities(prevActivities => [data, ...prevActivities]);

    // Refresh stats
    fetchStats();
  }, []);

  useEffect(() => {
    fetchActivities();
    fetchStats();
  }, [filters]);

  const fetchActivities = async () => {
    try {
      const params = new URLSearchParams();
      if (filters.action) params.append('action', filters.action);
      if (filters.resource) params.append('resource', filters.resource);
      if (filters.status) params.append('status', filters.status);
      params.append('limit', filters.limit);

      const response = await api.get(`/activities?${params}`);
      setActivities(response.data);
    } catch (error) {
      console.error('Failed to fetch activities:', error);
    } finally {
      setLoading(false);
    }
  };

  const fetchStats = async () => {
    try {
      const response = await api.get('/activities/stats');
      setStats(response.data);
    } catch (error) {
      console.error('Failed to fetch stats:', error);
    }
  };

  const getStatusBadge = (status) => {
    const badges = {
      success: 'status-success',
      error: 'status-error',
      running: 'status-running',
      pending: 'status-pending',
      fail: 'status-error'
    };
    return badges[status] || 'status-default';
  };

  const getActionIcon = (action) => {
    const icons = {
      create: '➕',
      update: '✏️',
      delete: '🗑️',
      test: '🧪',
      login: '🔐',
      logout: '🚪'
    };
    return icons[action] || '📝';
  };

  const formatDate = (dateString) => {
    const date = new Date(dateString);
    return date.toLocaleString('en-US', {
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
      second: '2-digit'
    });
  };

  if (loading) return <div className="loading">Loading activities...</div>;

  return (
    <div className="activity-log">
      <div className="activity-header">
        <h1>Activity Log</h1>
        <p>All system activities and user actions</p>
      </div>

      {stats && (
        <div className="stats-grid">
          <div className="stat-card">
            <div className="stat-value">{stats.total}</div>
            <div className="stat-label">Total Activities</div>
          </div>
          <div className="stat-card">
            <div className="stat-value">{stats.today}</div>
            <div className="stat-label">Today</div>
          </div>
          {stats.by_status && stats.by_status.map(stat => (
            <div className="stat-card" key={stat.status}>
              <div className="stat-value">{stat.count}</div>
              <div className="stat-label">{stat.status}</div>
            </div>
          ))}
        </div>
      )}

      <div className="filters">
        <select
          value={filters.action}
          onChange={(e) => setFilters({ ...filters, action: e.target.value })}
        >
          <option value="">All Actions</option>
          <option value="create">Create</option>
          <option value="update">Update</option>
          <option value="delete">Delete</option>
          <option value="test">Test</option>
        </select>

        <select
          value={filters.resource}
          onChange={(e) => setFilters({ ...filters, resource: e.target.value })}
        >
          <option value="">All Resources</option>
          <option value="website">Website</option>
          <option value="smoke_test">Smoke Test</option>
          <option value="performance_test">Performance Test</option>
        </select>

        <select
          value={filters.status}
          onChange={(e) => setFilters({ ...filters, status: e.target.value })}
        >
          <option value="">All Statuses</option>
          <option value="success">Success</option>
          <option value="error">Error</option>
          <option value="running">Running</option>
        </select>

        <select
          value={filters.limit}
          onChange={(e) => setFilters({ ...filters, limit: parseInt(e.target.value) })}
        >
          <option value="50">Last 50</option>
          <option value="100">Last 100</option>
          <option value="200">Last 200</option>
          <option value="500">Last 500</option>
        </select>

        <button onClick={fetchActivities} className="refresh-btn">
          Refresh
        </button>
      </div>

      <div className="activities-list">
        {activities.length === 0 ? (
          <div className="empty-state">No activities found</div>
        ) : (
          <table className="activities-table">
            <thead>
              <tr>
                <th>Time</th>
                <th>User</th>
                <th>Action</th>
                <th>Resource</th>
                <th>Status</th>
                <th>Details</th>
              </tr>
            </thead>
            <tbody>
              {activities.map((activity) => (
                <tr key={activity.id}>
                  <td className="time-col">{formatDate(activity.created_at)}</td>
                  <td>
                    <span className="user-badge">{activity.user || 'system'}</span>
                  </td>
                  <td>
                    <span className="action-cell">
                      <span className="action-icon">{getActionIcon(activity.action)}</span>
                      {activity.action}
                    </span>
                  </td>
                  <td>{activity.resource}</td>
                  <td>
                    <span className={`status-badge ${getStatusBadge(activity.status)}`}>
                      {activity.status}
                    </span>
                  </td>
                  <td className="metadata-col">
                    {activity.metadata && Object.keys(activity.metadata).length > 0 && (
                      <details>
                        <summary>View Details</summary>
                        <pre>{JSON.stringify(activity.metadata, null, 2)}</pre>
                      </details>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>
    </div>
  );
}
